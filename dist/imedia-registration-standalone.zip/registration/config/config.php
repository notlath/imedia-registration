<?php

/**
 * IMedia Registration — application configuration.
 *
 * Copy of config.example.php with production values.
 *
 * SECURITY: config.php is gitignored. Do not commit credentials.
 */

declare(strict_types=1);

return [

    'APP_DEBUG'      => false,

    // TODO (client): Replace with the full production URL where this app lives
    // e.g. https://clientdomain.com/wp-content/plugins/imedia-registration/public/
    'BASE_URL'       => 'https://www.inventivemedia.com.ph/imedia-registration',

    // ----- Database (cPanel MySQL) -----
    // TODO (client): Create a separate database for the standalone app in cPanel MySQL
    'DB_HOST'        => 'localhost',
    'DB_PORT'        => 3306,
    'DB_NAME'        => 'REPLACE_WITH_STANDALONE_DB_NAME',        // e.g. cpanel_imreg
    'DB_USER'        => 'REPLACE_WITH_STANDALONE_DB_USER',        // e.g. cpanel_imreg
    'DB_PASS'        => 'REPLACE_WITH_STANDALONE_DB_PASSWORD',
    'DB_CHARSET'     => 'utf8mb4',

    // ----- Session -----
    'SESSION_NAME'   => 'imreg_session',
    'SESSION_LIFETIME' => 7200,                                    // 2 hours
    'SESSION_SECURE' => true,                                      // require HTTPS
    'SESSION_HTTPONLY' => true,
    'SESSION_SAMESITE' => 'Lax',

    // ----- HMAC -----
    // TODO (client): Generate with: php -r "echo bin2hex(random_bytes(32));"
    // Paste the output here AND in WP Admin > IMedia Registration > Settings > Shared Secret
    // 'HMAC_SECRET' => defined elsewhere or set in env

    // ----- Mail (SMTP) -----
    // TODO (client): Configure SMTP via the admin panel at /admin/settings
    'MAIL_FROM_EMAIL' => 'REPLACE_WITH_CLIENT_EMAIL',             // e.g. noreply@client.com

    // ----- Logging -----
    'LOG_PATH'       => __DIR__ . '/../storage/logs/app.log',
    'LOG_LEVEL'      => 'warning',                                // 'debug' | 'info' | 'warning' | 'error'
];
